package com.example.lab08.a2mart_ornek1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView ivKopek,ivKedi,ivBalik,ivKus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ivKopek = findViewById(R.id.ivKopek);
        ivKedi = findViewById(R.id.ivKedi);
        ivBalik = findViewById(R.id.ivBalik);
        ivKus = findViewById(R.id.ivKus);

        ivKopek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this,second.class);
                intent.putExtra("name","köpek");
                startActivity(intent);
            }
        });

        ivKedi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this,second.class);
                intent.putExtra("name","kedi");
                startActivity(intent);
            }
        });

        ivBalik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this,second.class);
                intent.putExtra("name","balık");
                startActivity(intent);
            }
        });

        ivKus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this,second.class);
                intent.putExtra("name","kuş");
                startActivity(intent);
            }
        });


    }
}
