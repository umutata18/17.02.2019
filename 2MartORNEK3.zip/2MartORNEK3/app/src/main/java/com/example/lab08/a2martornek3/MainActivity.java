package com.example.lab08.a2martornek3;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.example.lab08.a2martornek3.R;
import com.example.lab08.a2martornek3.SecondActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    @Override
    public void onClick(View v) {
        Button b = (Button) v;
        String yazi = b.getText().toString();
        // TIKLANILAN BUTONUN GÖRÜNEN YAZISINI YAKALADIK.
        Intent intent = new Intent(getApplicationContext(),SecondActivity.class);
        //BUTONUN GÖRÜNEN YAZISINI, 2. SAYFAYA TAŞIDIK.
        intent.putExtra("yazi",yazi);
        startActivity(intent);
    }

    public void butonlariEkle(int sayi){
        for(int i=0; i<sayi; i++){
            Button btn = new Button(getApplicationContext());
            btn.setText("Buton "+i);
            btn.setOnClickListener(this);
            linearLayout.addView(btn);
        }
    }

    LinearLayout linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linearLayout = findViewById(R.id.linear);
        butonlariEkle(20);
    }


}