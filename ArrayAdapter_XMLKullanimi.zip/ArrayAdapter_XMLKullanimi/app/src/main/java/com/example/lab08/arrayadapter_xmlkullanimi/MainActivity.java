package com.example.lab08.arrayadapter_xmlkullanimi;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    ListView listView;
    ArrayAdapter<String> adapter;
    String[] dizi;


    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        listView = findViewById(R.id.listview);
        adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.diller));



        //String xml dosyası içerisinbdeki bir string listesini adapter'a bağlayıp listview'da gösterdik.
        listView.setAdapter(adapter);


        dizi = getResources().getStringArray(R.array.diller);
        adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,dizi);



        //Listview nesnesinde bir satıra tıklanma olayı
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),""+dizi[position],Toast.LENGTH_LONG).show();
            }
        });

    }
}
