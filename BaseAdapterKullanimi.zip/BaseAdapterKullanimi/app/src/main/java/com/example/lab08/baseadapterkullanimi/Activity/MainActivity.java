package com.example.lab08.baseadapterkullanimi.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.example.lab08.baseadapterkullanimi.Adapter.AdapterMeyve;
import com.example.lab08.baseadapterkullanimi.Model.Meyve;
import com.example.lab08.baseadapterkullanimi.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Meyve> meyveler = new ArrayList<Meyve>();
    AdapterMeyve adapterMeyve;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        meyveler.add(new Meyve("Elma",R.drawable.elma));
        meyveler.add(new Meyve("Armut",R.drawable.armut));
        meyveler.add(new Meyve("Üzüm",R.drawable.uzum));
        meyveler.add(new Meyve("Kayısı",R.drawable.kayisi));

        adapterMeyve = new AdapterMeyve(meyveler,getApplicationContext());
        listView.setAdapter(adapterMeyve);

    }
}
