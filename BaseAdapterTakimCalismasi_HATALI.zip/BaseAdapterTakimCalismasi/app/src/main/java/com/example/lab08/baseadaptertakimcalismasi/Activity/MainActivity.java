package com.example.lab08.baseadaptertakimcalismasi.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.lab08.baseadaptertakimcalismasi.Adapter.AdapterTakim;
import com.example.lab08.baseadaptertakimcalismasi.Model.Takim;
import com.example.lab08.baseadaptertakimcalismasi.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Takim> takimlar = new ArrayList<Takim>();
    AdapterTakim adapterTakim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        takimlar.add(new Takim("GALATASARAY",R.drawable.galatasaray_logo));
        takimlar.add(new Takim("FENERBAHÇE",R.drawable.fenerbahce_logo));
        takimlar.add(new Takim("BEŞİKTAŞ",R.drawable.besiktas_logo));
        takimlar.add(new Takim("TRABZONSPOR",R.drawable.trabzonspor_logo));

        adapterTakim = new AdapterTakim(takimlar,getApplicationContext());
        listView.setAdapter(adapterTakim);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),OyuncularActivity.class);
                intent.putExtra("takim_adi",takimlar.get(position).getAd());
                startActivity(intent);

            }
        });
    }
}
