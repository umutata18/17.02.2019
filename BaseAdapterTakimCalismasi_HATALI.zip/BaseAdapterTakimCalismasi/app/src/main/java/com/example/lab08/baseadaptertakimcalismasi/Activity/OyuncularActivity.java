package com.example.lab08.baseadaptertakimcalismasi.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.lab08.baseadaptertakimcalismasi.Adapter.AdapterOyuncu;
import com.example.lab08.baseadaptertakimcalismasi.Model.Oyuncu;
import com.example.lab08.baseadaptertakimcalismasi.R;

import java.util.ArrayList;

public class OyuncularActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Oyuncu> oyuncular = new ArrayList<Oyuncu>();
    AdapterOyuncu adapterOyuncu;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyuncular);

        String takim = getIntent().getStringExtra("takim_adi");
        setTitle(takim);

        //Toolbar'a geri butonu ekler.
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listView = findViewById(R.id.listView);

        if (takim.equals("Galatasaray")) {
            oyuncular.add(new Oyuncu(1, "Fernando Muslera", "muslera", 33, 1));
            oyuncular.add(new Oyuncu(2, "Semih Kaya", "semihkaya", 27, 26));
        } else if (takim.equals("Fenerbahçe")) {
            oyuncular.add(new Oyuncu(1, "Harun Tekin", "haruntekin", 29, 35));
            oyuncular.add(new Oyuncu(2, "Volkan Demirel", "volkandemirel", 37, 1));

        }


        adapterOyuncu = new AdapterOyuncu(oyuncular, getApplicationContext());
        listView.setAdapter(adapterOyuncu);

    }



    //Geri butonuna basınca geri dönme işlemi
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
