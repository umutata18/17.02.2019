package com.example.lab08.baseadaptertakimcalismasi.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lab08.baseadaptertakimcalismasi.Model.Oyuncu;
import com.example.lab08.baseadaptertakimcalismasi.R;

import java.util.ArrayList;

public class AdapterOyuncu extends BaseAdapter{

    private ArrayList<Oyuncu> oyuncular;
    private Context context;
    private LayoutInflater layoutInflater;



    public AdapterOyuncu(ArrayList<Oyuncu> oyuncular, Context context) {
        this.oyuncular = oyuncular;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }



    @Override
    public int getCount() {
        return oyuncular.size();
    }

    @Override
    public Object getItem(int position) {
        return oyuncular.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.oyuncu_satirgoruntusu,null);

        TextView tvAdSoyad,tvYas,tvFormaNo;
        ImageView ivResim = v.findViewById(R.id.ivOyuncu);
        tvAdSoyad = v.findViewById(R.id.tvAdSoyad);
        tvYas = v.findViewById(R.id.tvYas);
        tvFormaNo = v.findViewById(R.id.tvFormaNo);

        tvAdSoyad.setText(oyuncular.get(position).getAdSoyad());
        tvFormaNo.setText(""+oyuncular.get(position).getFormaNo());
        tvYas.setText(""+oyuncular.get(position).getYas());

        int resim = v.getResources().getIdentifier(oyuncular.get(position).getResim(),"drawable",context.getPackageName());
        ivResim.setImageResource(resim);

        return v;
    }
}
