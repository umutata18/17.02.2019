package com.example.lab08.baseadaptertakimcalismasi.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lab08.baseadaptertakimcalismasi.Model.Takim;
import com.example.lab08.baseadaptertakimcalismasi.R;

import java.util.ArrayList;

public class AdapterTakim extends BaseAdapter{



    private ArrayList<Takim> takimlar;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterTakim(){}

    public AdapterTakim(ArrayList<Takim> takimlar,Context context){
        this.context = context;
        this.takimlar = takimlar;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public int getCount() {
        //Listenin eleman sayısı
        return takimlar.size();
    }

    @Override
    public Takim getItem(int position) {
        //Listenin i'nin sıradaki elemanını döner.
        return takimlar.get(position);
    }

    @Override
    public long getItemId(int position) {
        //Listedeki elemanın kaçıncı sırada olduğunu döner.
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //Liste elemanının satır görüntüsünü döner.
        //İndex = position

        View v = layoutInflater.inflate(R.layout.takim_satirgoruntusu,null);

        ImageView ivLogo = v.findViewById(R.id.ivLogo);
        TextView tvTakim = v.findViewById(R.id.tvTakim);

        tvTakim.setText(takimlar.get(position).getAd());

        ivLogo.setImageResource(takimlar.get(position).getLogo());

        return v;
    }
}
