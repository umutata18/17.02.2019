package com.example.lab08.baseadaptertakimcalismasi.Model;

public class Takim {
    private String ad;
    private int logo;

    public Takim() {
    }

    public Takim(String ad, int logo) {
        this.ad = ad;
        this.logo = logo;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public int getLogo() {
        return logo;
    }

    public void setLogo(int logo) {
        this.logo = logo;
    }
}
