package com.example.lab08.butonolaylari;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;


public class MainActivity extends AppCompatActivity {

    Button btn1,btn2,btn3;
    ToggleButton toggleButton;
    Switch aSwitch;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.button);
        btn2 = findViewById(R.id.button2);
        btn3 = findViewById(R.id.button3);
        toggleButton = findViewById(R.id.toggleButton);
        aSwitch = findViewById(R.id.switch1);

        //Açma kapama işlemi (.setOnCheckedChangeListener)
        toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Toast.makeText(getApplicationContext(),"Toggle seçili",Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getApplicationContext(),"Toggle seçili değil",Toast.LENGTH_LONG).show();
                }
            }
        });

        //Açma kapama işlemi (.setOnCheckedChangeListener)
        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Toast.makeText(getApplicationContext(),"Switch seçili",Toast.LENGTH_LONG).show();
                }else {
                    Toast.makeText(getApplicationContext(), "Switch seçili değil", Toast.LENGTH_LONG).show();
                }
            }
        });



        //Butona tıklama olayı
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(),"Butona tıklandı",Toast.LENGTH_LONG).show();
            }
        });

        //Butona uzun basılma olayı
        btn2.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(getApplicationContext(),"Butona uzun basıldı",Toast.LENGTH_LONG).show();
                return false;
            }
        });

        //Butona dokunma olayı
        btn3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Toast.makeText(getApplicationContext(),"Butona dokunuldu",Toast.LENGTH_LONG).show();
                return false;
            }
        });





    }
}

