package com.example.lab08.butonolaylari;

public class MainActivityÇalışmaNotları {
    /* İstediğimiz bir yapıyı import etmek için o yapıya tıklayıp ctrl+space basmamız gerekiyor.
    Bu işlemi yaptığımızda 2 tane tuş fazladan geliyor onları siliyoruz */


    /* Toast komutu mesajı ekranın en altında göstermeye yarar.4 bölümde incelenir.
    1) Toast.makeText(getApplicationContext(),          --> Bu bölüm zorunludur.
    2) "Toggle seçili",                                 --> Ekranda çıkmasını istediğimiz yazıyı görürüz.
    3) Toast.LENGTH_LONG)                               --> LENGTH_LONG komutuyla ekranda yazı 5 saniye kalır LENGTH_SHORT komutuyla 3 saniye kalır.
    4).show();                                          --> Kalıbın sonuna eklenmesi zorunludur.
    Toast.makeText(getApplicationContext(),"Toggle seçili",Toast.LENGTH_LONG).show();*/


    /* //Açma kapama işlemi (.setOnCheckedChangeListener)
    aSwitch.setOnCheckedChangeListener(new              --> Komutunu yazdıktan sonra ctrl+space yazarak komut otomatik gelir.*/

    /* //Butona tıklama olayı (.setOnClickListener(new View.OnClickListener()) */

    /* Butona dokunma olayı .(setOnTouchListener(new View.OnTouchListener())*/
}
