package com.example.lab08.customlistviewkullanimi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class ListViewAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<PhoneModel> arrayList;

    public ListViewAdapter(Context context,ArrayList<PhoneModel> arrayList){
        this.context = context;
        this.arrayList = arrayList;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return arrayList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return arrayList.get(i).getIndexId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = layoutInflater.inflate(R.layout.listview_custom_row,null);

        TextView tvNameSurname = (TextView) v.findViewById(R.id.tvNameSurname);
        TextView tvPhone = (TextView)v.findViewById(R.id.tvPhone);
        ImageView ivPhoto = (ImageView)v.findViewById(R.id.ivPhoto);

        tvNameSurname.setText(arrayList.get(i).getNameSurname());
        tvPhone.setText(arrayList.get(i).getPhoneNumber());
        Glide.with(context).load(arrayList.get(i).getPhoto()).into(ivPhoto);

        return v;
    }
}
