package com.example.lab08.customlistviewkullanimi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<PhoneModel> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        arrayList.add(
                new PhoneModel(1,"Şerif","0212 000 11 22","https://scontent-sof1-1.cdninstagram.com/vp/e44621ac6e0fa20dde7652d2431ad0ed/5B58D62F/t51.2885-19/s150x150/29738612_164502504253972_2938372867349282816_n.jpg")
        );
        arrayList.add(
                new PhoneModel(1,"Ben","0212 000 11 33","https://scontent-sof1-1.cdninstagram.com/vp/24eadfbcaceaa9eb394100e11a983923/5B5EE183/t51.2885-15/e35/29417489_358577954660719_7491071830703210496_n.jpg")
        );
        arrayList.add(
                new PhoneModel(1,"Sen","0212 000 11 44","https://scontent-sof1-1.cdninstagram.com/vp/eb8dbd9e324d721434d1b64caf168396/5B5DD012/t51.2885-15/e35/28752551_151094132251408_8689739882383278080_n.jpg")
        );
        arrayList.add(
                new PhoneModel(1,"O","0212 000 11 55","https://scontent-sof1-1.cdninstagram.com/vp/60a289ae42c3bd361803643a1bc93535/5B691A75/t51.2885-15/e35/29404300_159380121418069_42480559452061696_n.jpg")
        );
        arrayList.add(
                new PhoneModel(1,"Biz","0212 000 11 66","https://scontent-sof1-1.cdninstagram.com/vp/854b53c561e3494e3d4e052e519e8a90/5B5E29A3/t51.2885-15/e35/28763608_152561305415651_6929213314371158016_n.jpg")
        );
        arrayList.add(
                new PhoneModel(1,"Siz","0212 000 11 77","https://scontent-sof1-1.cdninstagram.com/vp/087d15b9cfd55ddd70da317f309e0e88/5B74A361/t51.2885-15/e35/29089015_174676626667408_7073313903853174784_n.jpg")
        );
        arrayList.add(
                new PhoneModel(1,"Onlar","0212 000 11 88","https://scontent-sof1-1.cdninstagram.com/vp/60a289ae42c3bd361803643a1bc93535/5B691A75/t51.2885-15/e35/29404300_159380121418069_42480559452061696_n.jpg")
        );

        listView = (ListView)findViewById(R.id.listView);
        ListViewAdapter adapter = new ListViewAdapter(getApplicationContext(),arrayList);
        listView.setAdapter(adapter);
    }
}