package com.example.lab08.hesaplamarnekleri;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    Button toplabtn,çıkarbtn,carpbtn,bölbtn;
    EditText etDeger1,etDeger2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toplabtn = findViewById(R.id.toplabtn1);
        çıkarbtn = findViewById(R.id.cıkarbtn1);
        carpbtn = findViewById(R.id.carpbtn1);
        bölbtn = findViewById(R.id.bölbtn1);

        etDeger1 = findViewById(R.id.etDeger1);
        etDeger2 = findViewById(R.id.etDeger2);




        toplabtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String deg1 = etDeger1.getText().toString();
                String deg2 = etDeger2.getText().toString();
                int deger1 =Integer.parseInt(deg1);
                int deger2=Integer.parseInt(deg2);
                Toast.makeText(getApplicationContext(),""+(deger1+deger2),Toast.LENGTH_LONG).show();
            }
        });

        çıkarbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String deg1 = etDeger1.getText().toString();
                String deg2 = etDeger2.getText().toString();
                int deger1 =Integer.parseInt(deg1);
                int deger2=Integer.parseInt(deg2);
                Toast.makeText(getApplicationContext(),""+(deger1-deger2),Toast.LENGTH_LONG).show();
            }
        });

        carpbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String deg1 = etDeger1.getText().toString();
                String deg2 = etDeger2.getText().toString();
                int deger1 =Integer.parseInt(deg1);
                int deger2=Integer.parseInt(deg2);
                Toast.makeText(getApplicationContext(),""+(deger1*deger2),Toast.LENGTH_LONG).show();
            }
        });

        bölbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String deg1 = etDeger1.getText().toString();
                String deg2 = etDeger2.getText().toString();
                int deger1 =Integer.parseInt(deg1);
                int deger2=Integer.parseInt(deg2);
                Toast.makeText(getApplicationContext(),""+(deger1/deger2),Toast.LENGTH_LONG).show();
            }
        });

    }
}
