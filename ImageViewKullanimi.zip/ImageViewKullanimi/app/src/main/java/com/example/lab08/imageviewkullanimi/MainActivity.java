package com.example.lab08.imageviewkullanimi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Button btngs,btnfb,btnts,btnbjk;
    ImageView iv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv = findViewById(R.id.ivResim);
        btngs = findViewById(R.id.btngs);
        btnfb = findViewById(R.id.btnfb);
        btnts = findViewById(R.id.btnts);
        btnbjk = findViewById(R.id.btnbjk);

        btngs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv.setImageResource(R.drawable.galatasaray);
            }
        });

        btnfb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv.setImageResource(R.drawable.fenerbahce);
            }
        });

        btnts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv.setImageResource(R.drawable.trabzonspor);
            }
        });

        btnbjk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv.setImageResource(R.drawable.besiktas);
            }
        });

    }
}