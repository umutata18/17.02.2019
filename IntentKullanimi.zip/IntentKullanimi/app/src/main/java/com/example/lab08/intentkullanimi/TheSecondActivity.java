package com.example.lab08.intentkullanimi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class TheSecondActivity extends AppCompatActivity {

    TextView twNameSurname;

    //Atama yapmak için set.Text();
    //Almak için get.Text();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_the_second);

        twNameSurname = findViewById(R.id.twNameSurname);
        //.getStringExtra("deneme");  burdaki extra başka bir sayfadan çağırdığımız için.
        String namesurname = getIntent().getStringExtra("namesurname");

        twNameSurname.setText(namesurname);

    }
}
