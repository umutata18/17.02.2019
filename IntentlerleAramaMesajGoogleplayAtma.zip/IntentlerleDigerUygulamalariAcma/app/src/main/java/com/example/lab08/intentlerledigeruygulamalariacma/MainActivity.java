package com.example.lab08.intentlerledigeruygulamalariacma;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etPhoneNumber,etNewPhoneNumber,etPhone1,etSMsContact,etKonu,etIcerik,etEmail;
    Button btnCall,btnNewCall,btn1,btnPlay,btnMap,btnEmail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        etNewPhoneNumber = findViewById(R.id.etNewPhoneNumber);
        etPhone1 = findViewById(R.id.etPhone1);
        etKonu=findViewById(R.id.etKonu);
        etIcerik=findViewById(R.id.etIcerik);
        etEmail=findViewById(R.id.etEmail);
        etSMsContact=findViewById(R.id.etSmsCONtact);

        btnCall = findViewById(R.id.btnCall);
        btnNewCall = findViewById(R.id.btnNewCall);
        btn1 = findViewById(R.id.btn1);
        btnPlay = findViewById(R.id.btnPlay);
        btnMap = findViewById(R.id.btnMap);
        btnEmail = findViewById(R.id.btnEmail);

        btnEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent e = new Intent(Intent.ACTION_SEND);

                    e.putExtra(Intent.EXTRA_EMAIL, etEmail.getText().toString());
                    e.setType("text/html");
                    e.putExtra(Intent.EXTRA_SUBJECT, etKonu.getText().toString());
                    e.putExtra(Intent.EXTRA_TEXT, etIcerik.getText().toString());
                    startActivity(Intent.createChooser(e, "choose app"));
                }catch(Exception e){

                }
            }
        });


        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent m = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("geo:0,0?q=41.016858,28.9470308,15z");
                m.setData(uri);
                startActivity(m);
            }
        });


        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try{
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("market://details?id=com.whatsapp"));
                    startActivity(intent);

                }catch(Exception e) {
                    Toast.makeText(getApplicationContext(), "Market yok", Toast.LENGTH_LONG).show();
                }
            }
        });


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent k = new Intent(Intent.ACTION_SENDTO);

                Uri uri = Uri.parse("sms"+etPhone1.getText().toString());


                k.putExtra("sms_body",etSMsContact.getText().toString());

                k.setData(uri);
                startActivity(k);

            }
        });



        btnNewCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent b = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("http:"+etPhoneNumber.getText().toString());
                b.setData(uri);
                startActivity(b);


            }
        });



        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("tel:"+etPhoneNumber.getText().toString());
                i.setData(uri);
                startActivity(i);


            }
        });

    }

}
