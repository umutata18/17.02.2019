package com.info.myapp1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    Button btn1,btn2;
    EditText editText1,editText2;
    ImageView imageView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.btnLogin);
        btn2 = findViewById(R.id.btnHesabınızYokMu);
        editText1 = findViewById(R.id.etGirisAdı);
        editText2 = findViewById(R.id.etGİrisParola);
        imageView = findViewById(R.id.imageView1);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editText1.getText().toString().equals("admin") && (editText2.getText().toString().equals("admin1234"))){
                    Toast.makeText(getApplicationContext(),"Giriş Başarılı",Toast.LENGTH_LONG).show();
                    Intent intocan = new Intent(MainActivity.this, SearchActivity.class);
                    startActivity(intocan);
                }else {
                    Toast.makeText(getApplicationContext(),"Giriş Başarısız",Toast.LENGTH_LONG).show();
                }
            }
        });


        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intocan = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intocan);
            }
        });


    }
}
