package com.info.myapp1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


public class RegisterActivity extends AppCompatActivity {

    Button btn1;
    EditText et1,et2,et3,et4;
    ImageView ımageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btn1 = findViewById(R.id.btnKayıt);
        et1 = findViewById(R.id.etGirisAdı);
        et2 = findViewById(R.id.etKayıtParola);
        et3 = findViewById(R.id.etKayıtEmail);
        et4 = findViewById(R.id.etKayıtTelefon);
        ımageView = findViewById(R.id.imageView2);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


    }
}
