package com.example.lab08.videoviewkullanimi;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.webkit.WebView;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    VideoView videoView;

    @Override
    public void onPause(){
        super.onPause();
        if (videoView!= null) {
            videoView.pause();
        }
    }
    @Override
    public void onResume() {
        super.onResume();
        if (videoView != null) {
            videoView.start();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);


        videoView = findViewById(R.id.videoView1);

        String videoPath="https://www.izlesene.com/video/ornek-videolar/6806436";
        Uri uri= Uri.parse(videoPath);

        VideoView video=(VideoView)findViewById(R.id.videoView1);
        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(video);

        video.setMediaController(mediaController);
        video.setVideoURI(uri);
        video.start();
    }
}
